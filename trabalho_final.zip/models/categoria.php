<?php

class categoria{
	public $_id_cat;
	public $_nome;
	
	function __construct($id_cat,$nome){
		this->_id_cat = $id_cat;
		this->_nome = $nome;
	}
}
?>