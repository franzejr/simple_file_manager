<meta http-equiv="content-type" 
	content="text/html;charset=utf-8" />
<?php
	include ("../tools.php");
	include ("../dao/usuarioDAO.php");

	//Pegando dados da Requisicao

	$titulo = $_POST["titulo"];
	$descricao = $_POST["descricao"];

?>