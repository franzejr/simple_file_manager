::<? include('includes/saudacao.php'); ?>
<h1>Menu</h1>
		<ul>
		
			<div id="saudacao">
			</div>
			<li><a href="seg/logoff.php">Logoff</a></li></li>
			<li><a href="#">Home</a></li>
			<li><a href="?pag=perfil">Meu Perfil</a></li>
			<li><a href="?pag=arquivo">Arquivos</a></li>
			<li><a href="?pag=categoria">Categorias</a></li>
			<li><a href="#">Contato</a></li>
		</ul>
		
<div id="banner">
			<img src="http://www.deti.ufc.br/moodle/theme/formal_white/logo.jpg" width="75" height="75" alt="banner"/>
</div>
		
