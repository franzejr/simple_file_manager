<h2>Categoria</h2>

<ul>
	<li><a href="?pag=adicionar_categoria">Adicionar</a></li>
	<li><a href="?pag=listar_categorias">Listar</a></li>
</ul>