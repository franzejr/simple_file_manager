<h2>Arquivo</h2>

<ul>
	<li><a href="?pag=adicionar_arquivo">Adicionar</a></li>
	<li><a href="?pag=listar_arquivos">Listagem Completa</a></li>
	<li><a href="?pag=listar">Listagem Simples</a></li>
	<li><a href="?pag=buscar_arquivos">Buscar</a></li>
</ul>