<style>
	#inicio{
		display: block; 
		width: 650px; 
		margin: 10px auto; 
		padding: 35px; 
		border: 1px solid #cbcbcb; 
		background-color: #FFF; 
	}
</style>

<div id="inicio">
		<h1>Bem-Vindo ao Sistema de Arquivos!</h1>
		<h5>Este sistema foi feito para gerenciamento de Arquivos</h5>
</div>
