<?php
	/*ArquivoDAO */
	
	echo "<h1>Testando o ArquivoDAO</h1>";
	$arquivoDAO = new ArquivoDAO();
	
	//Insert
	echo "<h2>Insert</h2>";
	
	//Update
	echo "<h2>Update</h2>";
	
	//Delete
	echo "<h2>Delete</h2>";
	

?>