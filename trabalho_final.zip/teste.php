<form method="post" action="recebe.php">
	<input type="text"  name="nome" />
</form>