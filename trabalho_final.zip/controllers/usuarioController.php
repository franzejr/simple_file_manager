<?php
	function listar(){
		
	}

?>