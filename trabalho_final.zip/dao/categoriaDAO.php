<?
/*
* Categoria DAO
*/

	function insert(){
		
	}
	
	function update(){
		
	}
	
	function delete(){
		
	}
?>