	
		<div id="login">
			
			<form action="actions/action_login.php" method="post">
					<div>
						<label for="cpf">Usuário: 
							    <input type="text" name="usuario" id="usuario" maxlength="20" size="20" />
						</label>
					</div>
					<div>
						<label for="log_senha">Senha: 
							<input type="password" name="senha" id="senha" >
						</label>
					</div>
					<center>
					<div id="submit">
					<input  type="submit" value="Enviar"  />
					</div>
					<a href="cadastrar.php">Cadastre-se!</a>
					</center>
			</form>
		</div>
			
